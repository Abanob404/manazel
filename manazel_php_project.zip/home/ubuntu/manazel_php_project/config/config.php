<?php
// Database Configuration
define("DB_HOST", "localhost");
define("DB_USER", "your_db_user");
define("DB_PASS", "your_db_password");
define("DB_NAME", "manazel_db");

// Site Configuration
define("SITE_URL", "http://localhost/manazel_php_project/public_html"); // Adjust if using a virtual host
define("SITE_NAME", "Manazel Real Estate");
define("DEFAULT_LANGUAGE", "en"); // en or ar

// Paths
define("ROOT_PATH", dirname(__DIR__)); // Should point to manazel_php_project
define("CONFIG_PATH", ROOT_PATH . "/config");
define("PUBLIC_PATH", ROOT_PATH . "/public_html");
define("SRC_PATH", ROOT_PATH . "/src");
define("TEMPLATES_PATH", ROOT_PATH . "/templates");
define("LANG_PATH", ROOT_PATH . "/lang");
define("INCLUDES_PATH", ROOT_PATH . "/includes");

// Error Reporting (Development vs Production)
// For development:
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);
// For production, you would typically set display_errors to 0 and log errors to a file.

// Session Configuration
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set default timezone
date_default_timezone_set("Asia/Dubai"); // Or your preferred timezone

?>
