<?php
// includes/functions.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * Loads the appropriate language file based on session or default setting.
 *
 * @return array The language array.
 */
function load_language(): array {
    if (!defined("DEFAULT_LANGUAGE") || !defined("LANG_PATH")) {
        // Fallback if constants are not defined, though they should be from config.php
        error_log("Language constants not defined. Check config.php and bootstrap.php");
        return []; // Return empty array or a default minimal set
    }

    $current_lang_code = DEFAULT_LANGUAGE;

    if (isset($_GET["lang"]) && in_array($_GET["lang"], ["en", "ar"])) {
        $_SESSION["lang"] = $_GET["lang"];
        // Redirect to remove lang from URL query string to avoid it being sticky on all links
        // This is a simple way; a more robust router would handle this cleaner
        $protocol = (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" || $_SERVER["SERVER_PORT"] == 443) ? "https://" : "http://";
        $host = $_SERVER["HTTP_HOST"];
        $uri = strtok($_SERVER["REQUEST_URI"], ".");
        // header("Location: " . $protocol . $host . $uri);
        // exit;
        $current_lang_code = $_SESSION["lang"];
    } elseif (isset($_SESSION["lang"])) {
        $current_lang_code = $_SESSION["lang"];
    }

    $lang_file_path = LANG_PATH . "/" . $current_lang_code . ".php";

    if (file_exists($lang_file_path)) {
        $lang_array = require $lang_file_path;
        if (is_array($lang_array)) {
            return $lang_array;
        }
    }
    // Fallback to default language if current selection fails or file doesn't exist
    $default_lang_file_path = LANG_PATH . "/" . DEFAULT_LANGUAGE . ".php";
    if (file_exists($default_lang_file_path)) {
        $lang_array = require $default_lang_file_path;
         if (is_array($lang_array)) {
            return $lang_array;
        }
    }
    error_log("Language file not found for code: " . $current_lang_code . " or default: " . DEFAULT_LANGUAGE);
    return []; // Return empty if no language file found
}

/**
 * Retrieves a translated string for a given key.
 *
 * @param string $key The key for the translation string.
 * @param array $lang_array The loaded language array.
 * @return string The translated string, or the key itself if not found.
 */
function trans(string $key, array $lang_array = null): string {
    global $lang; // Use the global $lang variable loaded in index.php or bootstrap
    if ($lang_array === null) {
        $lang_array = $lang; // Use the globally loaded language array if not passed directly
    }

    if (isset($lang_array[$key])) {
        return htmlspecialchars($lang_array[$key], ENT_QUOTES, "UTF-8");
    }
    return htmlspecialchars($key, ENT_QUOTES, "UTF-8"); // Return the key itself if no translation found
}

// Add other global helper functions here as needed, e.g., for URL generation, asset loading, sanitization.

/**
 * Generates a full URL for a given path within the site.
 *
 * @param string $path The path relative to the site root (e.g., "listings", "property?id=123").
 * @return string The full URL.
 */
function site_url(string $path = "): string {
    if (!defined("SITE_URL")) {
        return "/"; // Fallback
    }
    return rtrim(SITE_URL, "/") . "/" . ltrim($path, "/");
}

/**
 * Escapes HTML output to prevent XSS.
 *
 * @param string|null $string The string to escape.
 * @return string The escaped string.
 */
function e(?string $string): string {
    return htmlspecialchars((string)$string, ENT_QUOTES, "UTF-8");
}

?>
