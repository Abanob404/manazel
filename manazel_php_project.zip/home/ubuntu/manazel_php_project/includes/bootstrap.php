<?php
// includes/bootstrap.php

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Define root path and site URL if not already defined
if (!defined("ROOT_PATH")) {
    define("ROOT_PATH", dirname(__DIR__)); // Assumes bootstrap.php is in /includes
}
if (!defined("SITE_URL")) {
    // Basic detection, might need adjustment based on server config
    $protocol = (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" || $_SERVER["SERVER_PORT"] == 443) ? "https://" : "http://";
    $host = $_SERVER["HTTP_HOST"];
    // Remove script name if accessing via index.php in a subdirectory
    $script_name = str_replace("/index.php", "", $_SERVER["SCRIPT_NAME"]);
    define("SITE_URL", $protocol . $host . $script_name);
}

// Define paths
if (!defined("INCLUDES_PATH")) {
    define("INCLUDES_PATH", ROOT_PATH . "/includes");
}
if (!defined("TEMPLATES_PATH")) {
    define("TEMPLATES_PATH", ROOT_PATH . "/templates");
}
if (!defined("SRC_PATH")) {
    define("SRC_PATH", ROOT_PATH . "/src");
}
if (!defined("LANG_PATH")) {
    define("LANG_PATH", ROOT_PATH . "/lang");
}
if (!defined("CONFIG_PATH")) {
    define("CONFIG_PATH", ROOT_PATH . "/config");
}

// Load configuration (database credentials etc.)
require_once CONFIG_PATH . "/config.php";

// Autoloader for classes (PSR-4 style)
spl_autoload_register(function ($class_name) {
    // Base directory for the namespace prefix
    $base_dir = ROOT_PATH . "/"; // Project root

    // Does the class use the namespace prefix?
    $prefix = "Src\\";
    $len = strlen($prefix);
    if (strncmp($prefix, $class_name, $len) !== 0) {
        // No, move to the next registered autoloader
        return;
    }

    // Get the relative class name
    $relative_class = substr($class_name, $len);

    // Replace the namespace prefix with the base directory, replace namespace
    // separators with directory separators in the relative class name, append
    // with .php
    $file = $base_dir . str_replace("\\", "/", $relative_class) . ".php";

    // If the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
});

// Load helper functions (like trans(), e())
require_once INCLUDES_PATH . "/functions.php";

// Language handling
if (isset($_GET["lang"])) {
    $selected_lang = $_GET["lang"];
    if (in_array($selected_lang, SUPPORTED_LANGUAGES)) {
        $_SESSION["lang"] = $selected_lang;
    }
    // Redirect to remove lang from query string, preserving other query params
    $query_params = $_GET;
    unset($query_params["lang"]);
    $redirect_url = strtok($_SERVER["REQUEST_URI"], ".") . (!empty($query_params) ? "?" . http_build_query($query_params) : "");
    header("Location: " . $redirect_url);
    exit;
}

// Load the language file based on session or default
$current_lang_code = $_SESSION["lang"] ?? DEFAULT_LANGUAGE;
$lang = load_language($current_lang_code);

// Global variable for language strings (already set by load_language)
global $lang;

// Set default timezone (optional, but good practice)
date_default_timezone_set("UTC");

?>
