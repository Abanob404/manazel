<?php
// lang/ar.php
return [
    // General
    "site_title" => "منازل للعقارات",
    "search_placeholder" => "ابحث بالمدينة، الرمز البريدي، أو العنوان...",
    "filter_button" => "تصفية",
    "submit_button" => "إرسال",
    "view_details_button" => "عرض التفاصيل",
    "read_more_button" => "اقرأ المزيد",
    "page_not_found_title" => "404 - الصفحة غير موجودة",
    "page_not_found_message" => "الصفحة التي تبحث عنها غير موجودة.",
    "go_home_button" => "الذهاب إلى الصفحة الرئيسية",

    // Navigation
    "nav_home" => "الرئيسية",
    "nav_about" => "من نحن",
    "nav_services" => "خدماتنا",
    "nav_listings" => "العقارات",
    "nav_contact" => "اتصل بنا",
    "nav_login" => "تسجيل الدخول",
    "nav_register" => "تسجيل جديد",
    "nav_profile" => "ملفي الشخصي",
    "nav_dashboard" => "لوحة التحكم",
    "nav_logout" => "تسجيل الخروج",
    "nav_admin_panel" => "لوحة الإدارة",
    "nav_manage_properties" => "إدارة العقارات",
    "nav_manage_users" => "إدارة المستخدمين",

    // Homepage
    "home_welcome" => "مرحباً بك في منازل للعقارات",
    "home_find_your_dream_property" => "ابحث عن عقار أحلامك",
    "featured_properties" => "العقارات المميزة",

    // About Us Page
    "about_us_title" => "عن منازل",
    "about_us_content" => "منازل للعقارات هي بوابة عقارية رائدة...", // محتوى مبدئي

    // Services Page
    "services_title" => "خدماتنا",
    "services_content" => "نحن نقدم مجموعة واسعة من الخدمات العقارية...", // محتوى مبدئي

    // Listings Page
    "listings_title" => "قائمة العقارات",
    "no_properties_found" => "لم يتم العثور على عقارات تطابق معايير البحث.",

    // Property Details Page
    "property_details_title" => "تفاصيل العقار",
    "price" => "السعر",
    "bedrooms" => "غرف النوم",
    "bathrooms" => "الحمامات",
    "area_sqft" => "المساحة (قدم مربع)",
    "property_type" => "نوع العقار",
    "description" => "الوصف",
    "features" => "المميزات",
    "location" => "الموقع",
    "rate_this_property" => "قيّم هذا العقار",
    "your_rating" => "تقييمك",
    "your_comment" => "تعليقك",
    "follow_property" => "متابعة هذا العقار",
    "unfollow_property" => "إلغاء متابعة هذا العقار",

    // Contact Page
    "contact_us_title" => "اتصل بنا",
    "contact_form_name" => "اسمك",
    "contact_form_email" => "بريدك الإلكتروني",
    "contact_form_subject" => "الموضوع",
    "contact_form_message" => "الرسالة",
    "send_message_button" => "إرسال الرسالة",

    // Auth Pages (Login/Register)
    "login_title" => "تسجيل الدخول إلى حسابك",
    "register_title" => "إنشاء حساب جديد",
    "username" => "اسم المستخدم",
    "password" => "كلمة المرور",
    "confirm_password" => "تأكيد كلمة المرور",
    "email" => "عنوان البريد الإلكتروني",
    "already_have_account" => "لديك حساب بالفعل؟ سجل الدخول من هنا.",
    "dont_have_account" => "ليس لديك حساب؟ سجل من هنا.",
    "login_failed" => "فشل تسجيل الدخول. يرجى التحقق من بيانات الاعتماد الخاصة بك.",
    "registration_successful" => "تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.",
    "registration_failed" => "فشل التسجيل. حاول مرة اخرى.",

    // User Profile Page
    "profile_title" => "ملفي الشخصي",
    "edit_profile" => "تعديل الملف الشخصي",
    "my_followed_properties" => "العقارات التي أتابعها",
    "my_ratings" => "تقييماتي",

    // Admin
    "admin_dashboard_title" => "لوحة تحكم المسؤول",
    "add_new_property" => "إضافة عقار جديد",
    "property_title_label" => "عنوان العقار",
    "property_address_label" => "العنوان",
    "property_city_label" => "المدينة",
    "property_state_label" => "الولاية/المقاطعة",
    "property_country_label" => "الدولة",
    "save_property_button" => "حفظ العقار",

    // أضف المزيد حسب الحاجة
];

