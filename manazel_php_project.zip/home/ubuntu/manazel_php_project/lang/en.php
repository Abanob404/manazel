<?php
// lang/en.php
return [
    // General
    "site_title" => "Manazel Real Estate",
    "search_placeholder" => "Search by city, zip, or address...",
    "filter_button" => "Filter",
    "submit_button" => "Submit",
    "view_details_button" => "View Details",
    "read_more_button" => "Read More",
    "page_not_found_title" => "404 - Page Not Found",
    "page_not_found_message" => "The page you are looking for does not exist.",
    "go_home_button" => "Go to Homepage",

    // Navigation
    "nav_home" => "Home",
    "nav_about" => "About Us",
    "nav_services" => "Services",
    "nav_listings" => "Listings",
    "nav_contact" => "Contact Us",
    "nav_login" => "Login",
    "nav_register" => "Register",
    "nav_profile" => "My Profile",
    "nav_dashboard" => "Dashboard",
    "nav_logout" => "Logout",
    "nav_admin_panel" => "Admin Panel",
    "nav_manage_properties" => "Manage Properties",
    "nav_manage_users" => "Manage Users",

    // Homepage
    "home_welcome" => "Welcome to Manazel Real Estate",
    "home_find_your_dream_property" => "Find Your Dream Property",
    "featured_properties" => "Featured Properties",

    // About Us Page
    "about_us_title" => "About Manazel",
    "about_us_content" => "Manazel Real Estate is a premier property portal...", // Placeholder

    // Services Page
    "services_title" => "Our Services",
    "services_content" => "We offer a wide range of real estate services...", // Placeholder

    // Listings Page
    "listings_title" => "Property Listings",
    "no_properties_found" => "No properties found matching your criteria.",

    // Property Details Page
    "property_details_title" => "Property Details",
    "price" => "Price",
    "bedrooms" => "Bedrooms",
    "bathrooms" => "Bathrooms",
    "area_sqft" => "Area (sq ft)",
    "property_type" => "Property Type",
    "description" => "Description",
    "features" => "Features",
    "location" => "Location",
    "rate_this_property" => "Rate this Property",
    "your_rating" => "Your Rating",
    "your_comment" => "Your Comment",
    "follow_property" => "Follow this Property",
    "unfollow_property" => "Unfollow this Property",

    // Contact Page
    "contact_us_title" => "Contact Us",
    "contact_form_name" => "Your Name",
    "contact_form_email" => "Your Email",
    "contact_form_subject" => "Subject",
    "contact_form_message" => "Message",
    "send_message_button" => "Send Message",

    // Auth Pages (Login/Register)
    "login_title" => "Login to your Account",
    "register_title" => "Create a New Account",
    "username" => "Username",
    "password" => "Password",
    "confirm_password" => "Confirm Password",
    "email" => "Email Address",
    "already_have_account" => "Already have an account? Login here.",
    "dont_have_account" => "Don\'t have an account? Register here.",
    "login_failed" => "Login failed. Please check your credentials.",
    "registration_successful" => "Registration successful! You can now log in.",
    "registration_failed" => "Registration failed. Please try again.",

    // User Profile Page
    "profile_title" => "My Profile",
    "edit_profile" => "Edit Profile",
    "my_followed_properties" => "My Followed Properties",
    "my_ratings" => "My Ratings",

    // Admin
    "admin_dashboard_title" => "Admin Dashboard",
    "add_new_property" => "Add New Property",
    "property_title_label" => "Property Title",
    "property_address_label" => "Address",
    "property_city_label" => "City",
    "property_state_label" => "State/Province",
    "property_country_label" => "Country",
    "save_property_button" => "Save Property",

    // Add more as needed
];

