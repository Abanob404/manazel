<?php
// public_html/index.php

// Include the bootstrap file to initialize the application
require_once __DIR__ . 
'/../includes/bootstrap.php
';

use Src\Auth\AuthController;
use Src\Property\PropertyController;
use Src\Admin\AdminController;

// Basic routing logic (to be expanded into a proper Router class)
$request_uri = strtok($_SERVER["REQUEST_URI"], ".");
$base_path = str_replace("/index.php", "", $_SERVER["SCRIPT_NAME"]);
$route = str_replace($base_path, "", $request_uri);
$route = trim($route, "/");

// Load the correct language file (already loaded in bootstrap.php, $lang is global)
global $lang;

$authCtrl = new AuthController();
$propertyCtrl = new PropertyController(); 
// AdminController instantiation is handled within its routes due to role check in constructor

// Simple router
switch ($route) {
    case "":
    case "home":
        $page_data = $propertyCtrl->index($_GET); // Get properties for homepage
        include TEMPLATES_PATH . "/pages/home.php";
        break;
    case "about":
        include TEMPLATES_PATH . "/pages/about.php";
        break;
    case "services":
        include TEMPLATES_PATH . "/pages/services.php";
        break;
    case "listings":
        $page_data = $propertyCtrl->index($_GET);
        include TEMPLATES_PATH . "/pages/listings.php";
        break;
    case "property":
        $property_id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
        $property = $propertyCtrl->show($property_id);
        include TEMPLATES_PATH . "/pages/property-details.php";
        break;
    case "contact":
        include TEMPLATES_PATH . "/pages/contact.php";
        break;
    case "login":
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $usernameOrEmail = $_POST["username"] ?? "";
            $password = $_POST["password"] ?? "";
            $login_result = $authCtrl->login($usernameOrEmail, $password);
            if ($login_result === true) {
                $redirect_url = $_GET["redirect"] ?? (AuthController::getCurrentUserRole() === "admin" ? SITE_URL . "/admin/dashboard" : SITE_URL . "/profile");
                header("Location: " . $redirect_url);
                exit;
            } else {
                $_SESSION["login_error"] = $login_result;
                header("Location: " . SITE_URL . "/login" . (isset($_GET["redirect"]) ? "?redirect=" . urlencode($_GET["redirect"]) : ""));
                exit;
            }
        }
        include TEMPLATES_PATH . "/pages/login.php";
        break;
    case "register":
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $username = $_POST["username"] ?? "";
            $email = $_POST["email"] ?? "";
            $password = $_POST["password"] ?? "";
            $confirm_password = $_POST["confirm_password"] ?? "";

            if ($password !== $confirm_password) {
                $_SESSION["register_error"] = "Passwords do not match.";
            } else {
                $registration_result = $authCtrl->register($username, $email, $password);
                if ($registration_result === true) {
                    $_SESSION["register_success"] = trans("registration_successful");
                } else {
                    $_SESSION["register_error"] = $registration_result;
                }
            }
            header("Location: " . SITE_URL . "/register");
            exit;
        }
        include TEMPLATES_PATH . "/pages/register.php";
        break;
    case "logout":
        $authCtrl->logout();
        header("Location: " . SITE_URL . "/login");
        exit;
    case "profile":
        AuthController::requireLogin();
        // Potentially load user data here for the profile page via a UserController
        include TEMPLATES_PATH . "/pages/profile.php";
        break;

    // Admin Routes
    case "admin/dashboard":
        $adminCtrl = new AdminController(); // Role check in constructor
        // Potentially load dashboard data here
        include TEMPLATES_PATH . "/pages/admin/dashboard.php";
        break;
    case "admin/manage-properties":
        $adminCtrl = new AdminController();
        $page_data = $adminCtrl->listProperties($_GET);
        include TEMPLATES_PATH . "/pages/admin/manage-properties.php";
        break;
    case "admin/property/add":
    case (preg_match("/admin\/property\/edit\/(\d+)/", $route, $matches) ? true : false):
        $adminCtrl = new AdminController();
        $property_id_to_edit = isset($matches[1]) ? (int)$matches[1] : null;
        $property_form_data = $adminCtrl->showPropertyForm($property_id_to_edit);
        if ($property_id_to_edit && !$property_form_data) { http_response_code(404); echo "Property not found for editing."; exit; }
        include TEMPLATES_PATH . "/pages/admin/property-form.php";
        break;
    case "admin/property/save":
        $adminCtrl = new AdminController();
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $result = $adminCtrl->saveProperty($_POST);
            if ($result === true) {
                $_SESSION["admin_message_success"] = "Property saved successfully.";
            } else {
                $_SESSION["admin_message_error"] = is_string($result) ? $result : "Failed to save property.";
            }
            header("Location: " . SITE_URL . "/admin/manage-properties");
            exit;
        }
        break;
    case (preg_match("/admin\/property\/delete\/(\d+)/", $route, $matches) ? true : false):
        $adminCtrl = new AdminController();
        $property_id_to_delete = (int)$matches[1];
        if ($adminCtrl->deleteProperty($property_id_to_delete)) {
            $_SESSION["admin_message_success"] = "Property deleted successfully.";
        } else {
            $_SESSION["admin_message_error"] = "Failed to delete property.";
        }
        header("Location: " . SITE_URL . "/admin/manage-properties");
        exit;
    case "admin/manage-users":
        $adminCtrl = new AdminController();
        $page_data = $adminCtrl->listUsers($_GET);
        include TEMPLATES_PATH . "/pages/admin/manage-users.php";
        break;
    case (preg_match("/admin\/user\/edit\/(\d+)/", $route, $matches) ? true : false):
        $adminCtrl = new AdminController();
        $user_id_to_edit = (int)$matches[1];
        $user_form_data = $adminCtrl->showUserForm($user_id_to_edit);
        if (!$user_form_data) { http_response_code(404); echo "User not found for editing."; exit; }
        include TEMPLATES_PATH . "/pages/admin/user-form.php";
        break;
    case "admin/user/save":
        $adminCtrl = new AdminController();
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $result = $adminCtrl->updateUser($_POST);
            if ($result === true) {
                $_SESSION["admin_message_success"] = "User updated successfully.";
            } else {
                $_SESSION["admin_message_error"] = is_string($result) ? $result : "Failed to update user.";
            }
            header("Location: " . SITE_URL . "/admin/manage-users");
            exit;
        }
        break;
    case (preg_match("/admin\/user\/delete\/(\d+)/", $route, $matches) ? true : false):
        $adminCtrl = new AdminController();
        $user_id_to_delete = (int)$matches[1];
        if ($adminCtrl->deleteUser($user_id_to_delete)) {
            $_SESSION["admin_message_success"] = "User deleted successfully.";
        } else {
            $_SESSION["admin_message_error"] = "Failed to delete user.";
        }
        header("Location: " . SITE_URL . "/admin/manage-users");
        exit;

    default:
        http_response_code(404);
        echo "<h1>" . trans("page_not_found_title") . "</h1>";
        echo "<p>" . trans("page_not_found_message") . "</p>";
        echo "<a href=\"" . SITE_URL . "\">" . trans("go_home_button") . "</a>";
        break;
}

?>
