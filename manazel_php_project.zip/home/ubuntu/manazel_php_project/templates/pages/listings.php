<?php 
// templates/pages/listings.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 
?>

<div class="container page-container">
    <h1><?php echo trans("listings_title"); ?></h1>

    <aside class="filters-sidebar">
        <h2><?php echo trans("filter_button"); ?></h2>
        <?php include TEMPLATES_PATH . 
'/partials/search_form.php'; ?>
        <!-- Add more advanced filter options here -->
        <h4><?php echo trans("property_type"); ?></h4>
        <ul>
            <li><input type="checkbox" name="type[]" value="apartment"> Apartment</li>
            <li><input type="checkbox" name="type[]" value="villa"> Villa</li>
            <li><input type="checkbox" name="type[]" value="commercial"> Commercial</li>
        </ul>
        <h4><?php echo trans("bedrooms"); ?></h4>
        <select name="bedrooms">
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
        </select>
         <h4><?php echo trans("price"); ?> Range</h4>
        <input type="number" name="min_price" placeholder="Min Price">
        <input type="number" name="max_price" placeholder="Max Price">
    </aside>

    <section class="property-listings-main">
        <div class="property-grid">
            <?php 
            // Placeholder for property listings loop
            // In a dynamic version, you would fetch these from the database based on filters
            $properties_found = true; // Simulate finding properties
            if ($properties_found):
                for ($i = 0; $i < 6; $i++): // Display 6 placeholder properties
            ?>
                    <div class="property-card">
                        <img src="<?php echo SITE_URL; ?>/assets/images/placeholder_property_<?php echo ($i % 3) + 1; ?>.png" alt="Property Image <?php echo $i+1; ?>">
                        <h3><?php echo trans("property_title_label"); ?> Placeholder <?php echo $i+1; ?></h3>
                        <p class="price"><?php echo trans("price"); ?>: $<?php echo number_format(rand(200000, 1500000), 0); ?></p>
                        <p><?php echo trans("bedrooms"); ?>: <?php echo rand(1, 5); ?> | <?php echo trans("bathrooms"); ?>: <?php echo rand(1, 4); ?> | <?php echo trans("area_sqft"); ?>: <?php echo rand(800, 3500); ?></p>
                        <a href="<?php echo SITE_URL; ?>/property?id=<?php echo $i+1; ?>" class="btn"><?php echo trans("view_details_button"); ?></a>
                    </div>
            <?php 
                endfor; 
            else:
            ?>
                <p><?php echo trans("no_properties_found"); ?></p>
            <?php endif; ?>
        </div>
        <!-- Basic Pagination Placeholder -->
        <nav class="pagination">
            <a href="#" class="active">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">Next &raquo;</a>
        </nav>
    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

