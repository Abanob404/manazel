<?php 
// templates/pages/register.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 

$error_message = "";
if (isset($_SESSION["register_error"])) {
    $error_message = $_SESSION["register_error"];
    unset($_SESSION["register_error"]); // Clear the message after displaying
}

$success_message = "";
if (isset($_SESSION["register_success"])) {
    $success_message = $_SESSION["register_success"];
    unset($_SESSION["register_success"]); // Clear the message after displaying
}

?>

<div class="container page-container auth-page">
    <h1><?php echo trans("register_title"); ?></h1>

    <?php if ($error_message): ?>
        <div class="alert alert-danger">
            <p><?php echo e($error_message); ?></p>
        </div>
    <?php endif; ?>

    <?php if ($success_message): ?>
        <div class="alert alert-success">
            <p><?php echo e($success_message); ?></p>
            <p><a href="<?php echo SITE_URL; ?>/login"><?php echo trans("nav_login"); ?></a></p>
        </div>
    <?php else: // Only show form if not successful ?>
    <form action="<?php echo SITE_URL; ?>/register" method="POST" class="auth-form">
        <div class="form-group">
            <label for="username"><?php echo trans("username"); ?></label>
            <input type="text" id="username" name="username" required value="<?php echo isset($_POST['username']) ? e($_POST['username']) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="email"><?php echo trans("email"); ?></label>
            <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? e($_POST['email']) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="password"><?php echo trans("password"); ?></label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="confirm_password"><?php echo trans("confirm_password"); ?></label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn"><?php echo trans("nav_register"); ?></button>
    </form>
    <?php endif; ?>
    <p class="auth-switch">
        <?php echo trans("already_have_account"); ?> <a href="<?php echo SITE_URL; ?>/login"><?php echo trans("nav_login"); ?></a>
    </p>
</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

