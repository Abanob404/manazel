<?php 
// templates/pages/contact.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 

// Handle form submission (basic example, needs validation and actual email sending logic)
$message_sent = false;
$error_message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $subject = trim($_POST["subject"] ?? '');
    $message_body = trim($_POST["message"] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message_body)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Simulate sending email
        // mail("your-email@example.com", "Contact Form: " . $subject, $message_body, "From: " . $email);
        $message_sent = true;
    }
}
?>

<div class="container page-container contact-page">
    <h1><?php echo trans("contact_us_title"); ?></h1>

    <?php if ($message_sent): ?>
        <div class="alert alert-success">
            <p>Thank you for your message! We will get back to you shortly.</p>
        </div>
    <?php endif; ?>

    <?php if ($error_message): ?>
        <div class="alert alert-danger">
            <p><?php echo e($error_message); ?></p>
        </div>
    <?php endif; ?>

    <form action="<?php echo SITE_URL; ?>/contact" method="POST" class="contact-form">
        <div class="form-group">
            <label for="name"><?php echo trans("contact_form_name"); ?></label>
            <input type="text" id="name" name="name" required value="<?php echo isset($_POST['name']) ? e($_POST['name']) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="email"><?php echo trans("contact_form_email"); ?></label>
            <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? e($_POST['email']) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="subject"><?php echo trans("contact_form_subject"); ?></label>
            <input type="text" id="subject" name="subject" required value="<?php echo isset($_POST['subject']) ? e($_POST['subject']) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="message"><?php echo trans("contact_form_message"); ?></label>
            <textarea id="message" name="message" rows="6" required><?php echo isset($_POST['message']) ? e($_POST['message']) : ''; ?></textarea>
        </div>
        <button type="submit" class="btn"><?php echo trans("send_message_button"); ?></button>
    </form>

    <section class="contact-details">
        <h2>Our Office</h2>
        <p><strong>Manazel Real Estate HQ</strong></p>
        <p>123 Real Estate Avenue, Suite 456</p>
        <p>Property City, PC 78901</p>
        <p><strong>Phone:</strong> +1 (555) 123-4567</p>
        <p><strong>Email:</strong> info@manazel.example.com</p>
        <!-- You can add a map here as well -->
    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

