<?php 
// templates/pages/profile.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 
use Src\Auth\AuthController;
use Src\Property\PropertyModel; // Required for fetching followed properties

AuthController::requireLogin(); // Protect this route

$current_user_id = AuthController::getCurrentUserId();
$db = Src\Core\Database::getInstance()->getConnection();
$propertyModel = new PropertyModel($db);
$userModel = new Src\User\UserModel($db);

$user = $userModel->findById($current_user_id);

// Handle profile update
$update_error_message = 
"";
$update_success_message = 
"";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_profile"])) {
    $new_username = $_POST["username"] ?? $user["username"];
    $new_email = $_POST["email"] ?? $user["email"];
    $new_password = $_POST["password"] ?? 
"";
    $confirm_password = $_POST["confirm_password"] ?? 
"";

    if (empty($new_username) || empty($new_email)) {
        $update_error_message = "Username and Email cannot be empty.";
    } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $update_error_message = "Invalid email format.";
    } elseif (!empty($new_password) && $new_password !== $confirm_password) {
        $update_error_message = "New passwords do not match.";
    } elseif (!empty($new_password) && strlen($new_password) < 6) {
        $update_error_message = "New password must be at least 6 characters long.";
    } else {
        $password_hash_to_update = !empty($new_password) ? password_hash($new_password, PASSWORD_DEFAULT) : null;
        if ($userModel->updateProfile($current_user_id, $new_username, $new_email, $password_hash_to_update)) {
            $update_success_message = "Profile updated successfully!";
            // Refresh user data
            $user = $userModel->findById($current_user_id);
            $_SESSION["username"] = $user["username"]; // Update session username if changed
        } else {
            $update_error_message = "Failed to update profile. Username or email might be taken.";
        }
    }
}


$followed_properties = $propertyModel->getFollowedPropertiesByUser($current_user_id, $lang["current_lang"]);

// Simulate user ratings (in a real app, fetch from RatingsModel)
$user_ratings = []; // Placeholder, fetch actual ratings
$stmt_ratings = $db->prepare("SELECT r.*, pt.title as property_title FROM ratings r JOIN property_translations pt ON r.property_id = pt.property_id WHERE r.user_id = :user_id AND pt.language_code = :lang_code ORDER BY r.created_at DESC");
$stmt_ratings->bindParam(":user_id", $current_user_id, PDO::PARAM_INT);
$stmt_ratings->bindParam(":lang_code", $lang["current_lang"]);
$stmt_ratings->execute();
$user_ratings = $stmt_ratings->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="container page-container profile-page">
    <h1><?php echo trans("profile_title"); ?></h1>

    <?php if ($update_success_message): ?>
        <div class="alert alert-success"><?php echo e($update_success_message); ?></div>
    <?php endif; ?>
    <?php if ($update_error_message): ?>
        <div class="alert alert-danger"><?php echo e($update_error_message); ?></div>
    <?php endif; ?>

    <section class="user-info">
        <h2><?php echo trans("welcome_username"); ?>, <?php echo e($user["username"]); ?>!</h2>
        
        <form action="<?php echo SITE_URL; ?>/profile" method="POST" class="profile-edit-form">
            <input type="hidden" name="update_profile" value="1">
            <div class="form-group">
                <label for="username"><?php echo trans("username"); ?>:</label>
                <input type="text" id="username" name="username" value="<?php echo e($user["username"]); ?>" required>
            </div>
            <div class="form-group">
                <label for="email"><?php echo trans("email"); ?>:</label>
                <input type="email" id="email" name="email" value="<?php echo e($user["email"]); ?>" required>
            </div>
            <div class="form-group">
                <label for="password"><?php echo trans("new_password_optional"); ?>:</label>
                <input type="password" id="password" name="password">
            </div>
            <div class="form-group">
                <label for="confirm_password"><?php echo trans("confirm_new_password"); ?>:</label>
                <input type="password" id="confirm_password" name="confirm_password">
            </div>
            <button type="submit" class="btn btn-primary"><?php echo trans("update_profile_button"); ?></button>
        </form>
        <p><strong><?php echo trans("member_since"); ?>:</strong> <?php echo date("M d, Y", strtotime($user["created_at"] ?? "now")); ?></p>
    </section>

    <section class="followed-properties">
        <h2><?php echo trans("my_followed_properties"); ?></h2>
        <?php if (!empty($followed_properties)):
            echo "<ul>";
            foreach ($followed_properties as $prop):
        ?>
            <li>
                <a href="<?php echo SITE_URL; ?>/property?id=<?php echo $prop["id"]; ?>">
                    <?php echo e($prop["title"]); ?>
                </a>
            </li>
        <?php 
            endforeach;
            echo "</ul>";
        else: ?>
            <p><?php echo trans("no_followed_properties_yet"); ?></p>
        <?php endif; ?>
    </section>

    <section class="user-ratings">
        <h2><?php echo trans("my_ratings"); ?></h2>
        <?php if (!empty($user_ratings)):
            echo "<ul>";
            foreach ($user_ratings as $rating):
        ?>
            <li>
                <strong>
                    <a href="<?php echo SITE_URL; ?>/property?id=<?php echo $rating["property_id"]; ?>">
                        <?php echo e($rating["property_title"]); ?>
                    </a>
                </strong>
                - <?php echo trans("your_rating"); ?>: <?php echo $rating["rating_value"]; ?>/5
                <?php if (!empty($rating["comment"])):
                ?>
                    <p><em>"<?php echo nl2br(e($rating["comment"])); ?>"</em></p>
                <?php endif; ?>
                 <small><?php echo date("M d, Y H:i", strtotime($rating["created_at"])); ?></small>
            </li>
        <?php 
            endforeach;
            echo "</ul>";
        else: ?>
            <p><?php echo trans("no_ratings_yet"); ?></p>
        <?php endif; ?>
    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php
'; ?>

