<?php 
// templates/pages/about.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 
?>

<div class="container page-container">
    <h1><?php echo trans("about_us_title"); ?></h1>
    
    <section class="about-content">
        <p><?php echo trans("about_us_content"); ?></p>
        
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        
        <h2>Our Mission</h2>
        <p>Our mission is to provide the best real estate services to our clients, ensuring transparency, integrity, and customer satisfaction. We aim to simplify the process of buying, selling, and renting properties.</p>
        
        <h2>Our Vision</h2>
        <p>To be the leading real estate platform recognized for its innovative solutions, extensive property listings, and exceptional customer service.</p>
        
        <h2>Our Team</h2>
        <p>We have a dedicated team of experienced real estate professionals who are passionate about helping you achieve your property goals. Meet our team (placeholder for team members section).</p>
    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

