<?php 
// templates/pages/services.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 
?>

<div class="container page-container">
    <h1><?php echo trans("services_title"); ?></h1>
    
    <section class="services-content">
        <p><?php echo trans("services_content"); ?></p>

        <div class="service-item">
            <h3>Property Buying Assistance</h3>
            <p>We guide you through every step of buying your new property, from searching to closing the deal. Our experts provide market insights and negotiation support.</p>
        </div>

        <div class="service-item">
            <h3>Property Selling Support</h3>
            <p>Maximize your property's potential with our selling services. We offer professional marketing, staging advice, and skilled negotiation to get you the best price.</p>
        </div>

        <div class="service-item">
            <h3>Rental Management</h3>
            <p>Comprehensive rental management services for landlords, including tenant screening, lease agreements, rent collection, and property maintenance.</p>
        </div>

        <div class="service-item">
            <h3>Property Valuation</h3>
            <p>Get an accurate valuation of your property based on current market trends and comparable sales. Essential for sellers, buyers, and investors.</p>
        </div>

        <div class="service-item">
            <h3>Real Estate Investment Consultancy</h3>
            <p>Expert advice for real estate investors, helping you identify lucrative opportunities and make informed decisions to grow your portfolio.</p>
        </div>

    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

