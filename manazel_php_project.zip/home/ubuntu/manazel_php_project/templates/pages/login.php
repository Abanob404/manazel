<?php 
// templates/pages/login.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 

$error_message = "";
if (isset($_SESSION["login_error"])) {
    $error_message = $_SESSION["login_error"];
    unset($_SESSION["login_error"]); // Clear the message after displaying
}
?>

<div class="container page-container auth-page">
    <h1><?php echo trans("login_title"); ?></h1>

    <?php if ($error_message): ?>
        <div class="alert alert-danger">
            <p><?php echo e($error_message); ?></p>
        </div>
    <?php endif; ?>

    <form action="<?php echo SITE_URL; ?>/login<?php echo isset($_GET["redirect"]) ? "?redirect=" . urlencode($_GET["redirect"]) : ""; ?>" method="POST" class="auth-form">
        <div class="form-group">
            <label for="username"><?php echo trans("username"); ?> / <?php echo trans("email"); ?></label>
            <input type="text" id="username" name="username" required value="<?php echo isset($_POST["username"]) ? e($_POST["username"]) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="password"><?php echo trans("password"); ?></label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn"><?php echo trans("nav_login"); ?></button>
    </form>
    <p class="auth-switch">
        <?php echo trans("dont_have_account"); ?> <a href="<?php echo SITE_URL; ?>/register"><?php echo trans("nav_register"); ?></a>
    </p>
</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

