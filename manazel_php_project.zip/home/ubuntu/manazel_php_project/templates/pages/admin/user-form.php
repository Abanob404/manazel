<?php 
// templates/pages/admin/user-form.php
$page_title = trans("edit_user_title");
require_once TEMPLATES_PATH . 
'/layouts/admin_layout.php';

// $user_form_data is populated by the router if editing
$is_editing = isset($user_form_data) && !empty($user_form_data["id"]);

if (!$is_editing) {
    // For this project, we are only supporting editing existing users via admin, not creating new ones from a blank form.
    // Redirect or show an error if no user ID is provided for editing.
    $_SESSION["admin_message_error"] = "No user selected for editing.";
    header("Location: " . SITE_URL . "/admin/manage-users");
    exit;
}

$u_id = $user_form_data["id"];
$u_username = $user_form_data["username"];
$u_email = $user_form_data["email"];
$u_role = $user_form_data["role"];

?>

<form action="<?php echo SITE_URL; ?>/admin/user/save" method="POST" class="admin-form">
    <input type="hidden" name="user_id" value="<?php echo $u_id; ?>">

    <fieldset>
        <legend><?php echo trans("user_details"); ?>: <?php echo e($u_username); ?></legend>
        <div class="form-group">
            <label for="username"><?php echo trans("username"); ?>:</label>
            <input type="text" name="username" id="username" value="<?php echo e($u_username); ?>" required>
        </div>
        <div class="form-group">
            <label for="email"><?php echo trans("email"); ?>:</label>
            <input type="email" name="email" id="email" value="<?php echo e($u_email); ?>" required>
        </div>
        <div class="form-group">
            <label for="role"><?php echo trans("role"); ?>:</label>
            <select name="role" id="role" <?php echo ($u_id == AuthController::getCurrentUserId() || $u_username == "admin") ? "disabled" : ""; // Prevent admin from easily changing their own role or the main admin's role via this form ?>>
                <option value="user" <?php echo ($u_role == "user") ? "selected" : ""; ?>><?php echo trans("role_user"); ?></option>
                <option value="admin" <?php echo ($u_role == "admin") ? "selected" : ""; ?>><?php echo trans("role_admin"); ?></option>
            </select>
            <?php if ($u_id == AuthController::getCurrentUserId() || $u_username == "admin"): ?>
                <input type="hidden" name="role" value="<?php echo e($u_role); ?>" />
                <small><?php echo trans("role_change_restriction_admin"); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="password"><?php echo trans("new_password_optional"); ?>:</label>
            <input type="password" name="password" id="password">
            <small><?php echo trans("leave_blank_to_keep_current_password"); ?></small>
        </div>
    </fieldset>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary"><?php echo trans("save_user_button"); ?></button>
        <a href="<?php echo SITE_URL; ?>/admin/manage-users" class="btn btn-secondary"><?php echo trans("cancel_button"); ?></a>
    </div>
</form>

<?php 
require_once TEMPLATES_PATH . 
'/layouts/footer_admin.php'; 
?>

