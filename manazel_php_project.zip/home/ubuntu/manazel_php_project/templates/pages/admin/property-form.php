<?php 
// templates/pages/admin/property-form.php
$page_title = $property_id_to_edit ? trans("edit_property_title") : trans("add_new_property");
require_once TEMPLATES_PATH . 
'/layouts/admin_layout.php';

// $property_form_data is populated by the router if editing
$is_editing = isset($property_form_data) && !empty($property_form_data["id"]);

$p_id = $is_editing ? $property_form_data["id"] : null;
$p_status = $is_editing ? $property_form_data["status"] : "available";
$p_price = $is_editing ? $property_form_data["price"] : "";
$p_bedrooms = $is_editing ? $property_form_data["bedrooms"] : "";
$p_bathrooms = $is_editing ? $property_form_data["bathrooms"] : "";
$p_area_sqft = $is_editing ? $property_form_data["area_sqft"] : "";
$p_property_type = $is_editing ? $property_form_data["property_type"] : "";
$p_latitude = $is_editing ? $property_form_data["latitude"] : "";
$p_longitude = $is_editing ? $property_form_data["longitude"] : "";

// Translations
$p_title_en = $is_editing ? ($property_form_data["translations_en"]["title"] ?? 
"") : "";
$p_description_en = $is_editing ? ($property_form_data["translations_en"]["description"] ?? 
"") : "";
$p_address_en = $is_editing ? ($property_form_data["translations_en"]["address_line1"] ?? 
"") : "";
$p_city_en = $is_editing ? ($property_form_data["translations_en"]["city"] ?? 
"") : "";
$p_state_en = $is_editing ? ($property_form_data["translations_en"]["state_province"] ?? 
"") : "";
$p_country_en = $is_editing ? ($property_form_data["translations_en"]["country"] ?? 
"") : "";

$p_title_ar = $is_editing ? ($property_form_data["translations_ar"]["title"] ?? 
"") : "";
$p_description_ar = $is_editing ? ($property_form_data["translations_ar"]["description"] ?? 
"") : "";
$p_address_ar = $is_editing ? ($property_form_data["translations_ar"]["address_line1"] ?? 
"") : "";
$p_city_ar = $is_editing ? ($property_form_data["translations_ar"]["city"] ?? 
"") : "";
$p_state_ar = $is_editing ? ($property_form_data["translations_ar"]["state_province"] ?? 
"") : "";
$p_country_ar = $is_editing ? ($property_form_data["translations_ar"]["country"] ?? 
"") : "";

?>

<form action="<?php echo SITE_URL; ?>/admin/property/save" method="POST" class="admin-form" enctype="multipart/form-data">
    <?php if ($is_editing): ?>
        <input type="hidden" name="property_id" value="<?php echo $p_id; ?>">
    <?php endif; ?>

    <fieldset>
        <legend><?php echo trans("property_details"); ?></legend>
        <div class="form-group">
            <label for="status"><?php echo trans("status"); ?>:</label>
            <select name="status" id="status">
                <option value="available" <?php echo ($p_status == "available") ? "selected" : ""; ?>><?php echo trans("status_available"); ?></option>
                <option value="sold" <?php echo ($p_status == "sold") ? "selected" : ""; ?>><?php echo trans("status_sold"); ?></option>
                <option value="rented" <?php echo ($p_status == "rented") ? "selected" : ""; ?>><?php echo trans("status_rented"); ?></option>
                <option value="pending" <?php echo ($p_status == "pending") ? "selected" : ""; ?>><?php echo trans("status_pending"); ?></option>
            </select>
        </div>
        <div class="form-group">
            <label for="price"><?php echo trans("price"); ?>:</label>
            <input type="number" name="price" id="price" value="<?php echo e($p_price); ?>" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="bedrooms"><?php echo trans("bedrooms"); ?>:</label>
            <input type="number" name="bedrooms" id="bedrooms" value="<?php echo e($p_bedrooms); ?>">
        </div>
        <div class="form-group">
            <label for="bathrooms"><?php echo trans("bathrooms"); ?>:</label>
            <input type="number" name="bathrooms" id="bathrooms" value="<?php echo e($p_bathrooms); ?>">
        </div>
        <div class="form-group">
            <label for="area_sqft"><?php echo trans("area_sqft"); ?>:</label>
            <input type="number" name="area_sqft" id="area_sqft" value="<?php echo e($p_area_sqft); ?>">
        </div>
        <div class="form-group">
            <label for="property_type"><?php echo trans("property_type"); ?>:</label>
            <input type="text" name="property_type" id="property_type" value="<?php echo e($p_property_type); ?>">
        </div>
        <div class="form-group">
            <label for="latitude"><?php echo trans("latitude"); ?>:</label>
            <input type="text" name="latitude" id="latitude" value="<?php echo e($p_latitude); ?>">
        </div>
        <div class="form-group">
            <label for="longitude"><?php echo trans("longitude"); ?>:</label>
            <input type="text" name="longitude" id="longitude" value="<?php echo e($p_longitude); ?>">
        </div>
    </fieldset>

    <fieldset>
        <legend><?php echo trans("property_information_en"); ?></legend>
        <div class="form-group">
            <label for="title_en"><?php echo trans("property_title_label"); ?> (EN):</label>
            <input type="text" name="title_en" id="title_en" value="<?php echo e($p_title_en); ?>" required>
        </div>
        <div class="form-group">
            <label for="description_en"><?php echo trans("description"); ?> (EN):</label>
            <textarea name="description_en" id="description_en" rows="5"><?php echo e($p_description_en); ?></textarea>
        </div>
        <div class="form-group">
            <label for="address_en"><?php echo trans("address_line1"); ?> (EN):</label>
            <input type="text" name="address_en" id="address_en" value="<?php echo e($p_address_en); ?>">
        </div>
        <div class="form-group">
            <label for="city_en"><?php echo trans("city"); ?> (EN):</label>
            <input type="text" name="city_en" id="city_en" value="<?php echo e($p_city_en); ?>">
        </div>
        <div class="form-group">
            <label for="state_en"><?php echo trans("state_province"); ?> (EN):</label>
            <input type="text" name="state_en" id="state_en" value="<?php echo e($p_state_en); ?>">
        </div>
        <div class="form-group">
            <label for="country_en"><?php echo trans("country"); ?> (EN):</label>
            <input type="text" name="country_en" id="country_en" value="<?php echo e($p_country_en); ?>">
        </div>
    </fieldset>

    <fieldset>
        <legend><?php echo trans("property_information_ar"); ?></legend>
        <div class="form-group">
            <label for="title_ar"><?php echo trans("property_title_label"); ?> (AR):</label>
            <input type="text" name="title_ar" id="title_ar" value="<?php echo e($p_title_ar); ?>" dir="rtl" required>
        </div>
        <div class="form-group">
            <label for="description_ar"><?php echo trans("description"); ?> (AR):</label>
            <textarea name="description_ar" id="description_ar" rows="5" dir="rtl"><?php echo e($p_description_ar); ?></textarea>
        </div>
        <div class="form-group">
            <label for="address_ar"><?php echo trans("address_line1"); ?> (AR):</label>
            <input type="text" name="address_ar" id="address_ar" value="<?php echo e($p_address_ar); ?>" dir="rtl">
        </div>
        <div class="form-group">
            <label for="city_ar"><?php echo trans("city"); ?> (AR):</label>
            <input type="text" name="city_ar" id="city_ar" value="<?php echo e($p_city_ar); ?>" dir="rtl">
        </div>
        <div class="form-group">
            <label for="state_ar"><?php echo trans("state_province"); ?> (AR):</label>
            <input type="text" name="state_ar" id="state_ar" value="<?php echo e($p_state_ar); ?>" dir="rtl">
        </div>
        <div class="form-group">
            <label for="country_ar"><?php echo trans("country"); ?> (AR):</label>
            <input type="text" name="country_ar" id="country_ar" value="<?php echo e($p_country_ar); ?>" dir="rtl">
        </div>
    </fieldset>

    <!-- Placeholder for image uploads -->
    <fieldset>
        <legend><?php echo trans("property_images"); ?></legend>
        <div class="form-group">
            <label for="images"><?php echo trans("upload_images"); ?>:</label>
            <input type="file" name="images[]" id="images" multiple>
        </div>
        <!-- Display existing images with options to delete or set primary -->
    </fieldset>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary"><?php echo trans("save_property_button"); ?></button>
        <a href="<?php echo SITE_URL; ?>/admin/manage-properties" class="btn btn-secondary"><?php echo trans("cancel_button"); ?></a>
    </div>
</form>

<?php 
require_once TEMPLATES_PATH . 
'/layouts/footer_admin.php'; 
?>

