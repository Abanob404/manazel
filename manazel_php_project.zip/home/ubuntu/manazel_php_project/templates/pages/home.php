<?php 
// templates/pages/home.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 
?>

<div class="container">
    <h1><?php echo trans("home_welcome"); ?></h1>
    <p><?php echo trans("home_find_your_dream_property"); ?></p>

    <section class="search-section">
        <h2><?php echo trans("search_placeholder"); ?></h2>
        <?php include TEMPLATES_PATH . 
'/partials/search_form.php'; ?>
    </section>

    <section class="featured-properties">
        <h2><?php echo trans("featured_properties"); ?></h2>
        <div class="property-grid">
            <?php 
            // Placeholder for featured properties loop
            // In a dynamic version, you would fetch these from the database
            for ($i = 0; $i < 3; $i++): 
            ?>
                <div class="property-card">
                    <img src="<?php echo SITE_URL; ?>/assets/images/placeholder_property.png" alt="Property Image">
                    <h3><?php echo trans("property_title_label"); ?> Placeholder <?php echo $i+1; ?></h3>
                    <p class="price"><?php echo trans("price"); ?>: $500,000</p>
                    <p><?php echo trans("bedrooms"); ?>: 3 | <?php echo trans("bathrooms"); ?>: 2 | <?php echo trans("area_sqft"); ?>: 1500</p>
                    <a href="<?php echo SITE_URL; ?>/property?id=<?php echo $i+1; ?>" class="btn"><?php echo trans("view_details_button"); ?></a>
                </div>
            <?php endfor; ?>
        </div>
    </section>

</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

