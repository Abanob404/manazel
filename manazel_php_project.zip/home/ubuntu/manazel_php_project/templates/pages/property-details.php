<?php 
// templates/pages/property-details.php
require_once TEMPLATES_PATH . 
'/layouts/header.php'; 

use Src\Auth\AuthController; // For checking login status and getting user ID

// $property is assumed to be populated by the router/controller
// $property should now include: images, ratings, avg_rating, user_rating (if logged in), is_followed_by_user (if logged in)

$property_id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
// The actual fetching of $property is done in index.php router via PropertyController->show($property_id)

$current_user_id = AuthController::getCurrentUserId();

?>

<div class="container page-container property-details-page">
    <?php if ($property && isset($property["id"])): ?>
        <h1><?php echo trans("property_details_title"); ?>: <?php echo e($lang["current_lang"] == "ar" ? ($property["title_ar"] ?? $property["title"]) : ($property["title_en"] ?? $property["title"])); ?></h1>

        <section class="property-gallery">
            <?php if (!empty($property["images"])) : ?>
                <img src="<?php echo e($property["images"][0]["image_url"]); ?>" alt="<?php echo e($lang["current_lang"] == "ar" ? ($property["title_ar"] ?? $property["title"]) : ($property["title_en"] ?? $property["title"])); ?>" class="main-property-image">
                <?php if (count($property["images"]) > 1): ?>
                <div class="thumbnails">
                    <?php foreach ($property["images"] as $image): ?>
                        <img src="<?php echo e($image["image_url"]); ?>" alt="Thumbnail <?php echo e($image["alt_text_en"] ?? 
""); ?>">
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            <?php else: ?>
                 <img src="<?php echo SITE_URL; ?>/assets/images/placeholder_property_1.png" alt="Placeholder Property Image" class="main-property-image">
            <?php endif; ?>
        </section>

        <section class="property-info">
            <div class="info-grid">
                <div><strong><?php echo trans("price"); ?>:</strong> $<?php echo number_format($property["price"]); ?></div>
                <div><strong><?php echo trans("property_type"); ?>:</strong> <?php echo e($lang["current_lang"] == "ar" ? ($property["property_type_ar"] ?? $property["property_type"]) : ($property["property_type_en"] ?? $property["property_type"])); ?></div>
                <div><strong><?php echo trans("bedrooms"); ?>:</strong> <?php echo $property["bedrooms"]; ?></div>
                <div><strong><?php echo trans("bathrooms"); ?>:</strong> <?php echo $property["bathrooms"]; ?></div>
                <div><strong><?php echo trans("area_sqft"); ?>:</strong> <?php echo $property["area_sqft"]; ?> sq ft</div>
                <div><strong><?php echo trans("location"); ?>:</strong> <?php echo e($lang["current_lang"] == "ar" ? ($property["address_ar"] ?? $property["address_line1"]) : ($property["address_en"] ?? $property["address_line1"])); ?></div>
            </div>
            <div class="average-rating">
                <strong><?php echo trans("average_rating"); ?>:</strong> 
                <?php if ($property["avg_rating"] !== null): ?>
                    <?php echo number_format($property["avg_rating"], 1); ?> / 5 (<?php echo count($property["ratings"]); ?> <?php echo trans("ratings_count_label"); ?>)
                <?php else: ?>
                    <?php echo trans("not_rated_yet"); ?>
                <?php endif; ?>
            </div>
        </section>

        <section class="property-description">
            <h2><?php echo trans("description"); ?></h2>
            <p><?php echo nl2br(e($lang["current_lang"] == "ar" ? ($property["description_ar"] ?? $property["description"]) : ($property["description_en"] ?? $property["description"]))); ?></p>
        </section>

        <section class="property-features-list">
            <h2><?php echo trans("features"); ?></h2>
            <?php 
            // Assuming features are stored as a comma-separated string or JSON in DB, or a related table.
            // For now, using placeholder from initial static version if dynamic not available.
            $features_list = $lang["current_lang"] == "ar" ? ($property["features_ar"] ?? []) : ($property["features_en"] ?? []);
            if (is_string($features_list)) $features_list = explode(",", $features_list); // Basic handling if it was a string
            ?>
            <?php if (!empty($features_list) && is_array($features_list)): ?>
            <ul>
                <?php foreach ($features_list as $feature): ?>
                    <li><?php echo e(trim($feature)); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            <p>No specific features listed.</p>
            <?php endif; ?>
        </section>

        <section class="property-map">
            <h2><?php echo trans("location"); ?> Map</h2>
            <div id="map-placeholder" style="width:100%; height:400px; background-color:#e0e0e0; text-align:center; line-height:400px;">
                Map will be displayed here (Lat: <?php echo e($property["latitude"] ?? "N/A"); ?>, Lng: <?php echo e($property["longitude"] ?? "N/A"); ?>)
            </div>
        </section>

        <section class="property-actions">
            <?php if (AuthController::isLoggedIn()): ?>
                <div class="follow-action">
                    <form action="<?php echo SITE_URL; ?>/property/toggle-follow" method="POST" style="display:inline;">
                        <input type="hidden" name="property_id" value="<?php echo $property["id"]; ?>">
                        <button type="submit" class="btn <?php echo $property["is_followed_by_user"] ? "btn-warning" : "btn-secondary"; ?>">
                            <?php echo $property["is_followed_by_user"] ? trans("unfollow_property") : trans("follow_property"); ?>
                        </button>
                    </form>
                </div>

                <hr>
                <h3><?php echo trans("rate_this_property"); ?></h3>
                <form action="<?php echo SITE_URL; ?>/property/rate" method="POST" class="rating-form">
                    <input type="hidden" name="property_id" value="<?php echo $property["id"]; ?>">
                    <div class="form-group">
                        <label for="rating_value"><?php echo trans("your_rating"); ?> (1-5):</label>
                        <select name="rating_value" id="rating_value" required>
                            <option value="">-- Select Rating --</option>
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <option value="<?php echo $i; ?>" <?php echo (isset($property["user_rating"]["rating_value"]) && $property["user_rating"]["rating_value"] == $i) ? "selected" : ""; ?>><?php echo $i; ?> Stars</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="comment"><?php echo trans("comment"); ?> (Optional):</label>
                        <textarea name="comment" id="comment" rows="3"><?php echo e($property["user_rating"]["comment"] ?? 
""); ?></textarea>
                    </div>
                    <button type="submit" class="btn"><?php echo trans("submit_rating_button"); ?></button>
                </form>
            <?php else: ?>
                <p><a href="<?php echo SITE_URL; ?>/login?redirect=<?php echo urlencode($_SERVER["REQUEST_URI"]); ?>"><?php echo trans("login_to_rate_follow"); ?></a></p>
            <?php endif; ?>
        </section>

        <section class="property-ratings-list">
            <h2><?php echo trans("user_ratings_title"); ?></h2>
            <?php if (!empty($property["ratings"])):
                foreach ($property["ratings"] as $rating):
            ?>
                <div class="rating-item">
                    <p><strong><?php echo e($rating["username"]); ?>:</strong> <?php echo $rating["rating_value"]; ?>/5 stars</p>
                    <?php if (!empty($rating["comment"])): ?>
                        <p><em>"<?php echo nl2br(e($rating["comment"])); ?>"</em></p>
                    <?php endif; ?>
                    <small><?php echo date("M d, Y H:i", strtotime($rating["created_at"])); ?></small>
                </div>
                <hr>
            <?php 
                endforeach;
            else:
            ?>
                <p><?php echo trans("no_ratings_yet"); ?></p>
            <?php endif; ?>
        </section>

    <?php else: ?>
        <h1><?php echo trans("page_not_found_title"); ?></h1>
        <p><?php echo trans("no_properties_found"); ?> (Property ID: <?php echo $property_id; ?> not found or invalid)</p>
        <a href="<?php echo SITE_URL; ?>/listings" class="btn"><?php echo trans("go_home_button"); ?></a>
    <?php endif; ?>
</div>

<?php require_once TEMPLATES_PATH . 
'/layouts/footer.php'; ?>

