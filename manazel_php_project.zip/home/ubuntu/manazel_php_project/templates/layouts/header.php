<?php
// templates/layouts/header.php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Ensure session is started
}
require_once dirname(__FILE__) . 
'/../../includes/functions.php

'; // For trans() and SITE_URL, e()

// Language is loaded in bootstrap.php, $lang should be global or accessible
global $lang;
if (empty($lang)) { // Fallback if bootstrap didn't run or $lang not globalized properly
    $lang = load_language($_SESSION["lang"] ?? DEFAULT_LANGUAGE);
}

$current_page = basename($_SERVER["PHP_SELF"], ".php");
if (empty($current_page) && isset($_SERVER["REQUEST_URI"])) {
    $uri_path = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
    $uri_segments = explode("/", trim($uri_path, "/"));
    $current_page = end($uri_segments);
    if (empty($current_page)) $current_page = "home";
}

?>
<!DOCTYPE html>
<html lang="<?php echo e($lang["current_lang"]); ?>" dir="<?php echo e($lang["direction"]); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? e($page_title) . " - " : ""; ?><?php echo trans("site_title"); ?></title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    <?php if ($lang["direction"] === "rtl"): ?>
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style-rtl.css">
    <?php endif; ?>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <a href="<?php echo SITE_URL; ?>" class="navbar-brand"><?php echo trans("site_logo_text"); // Manazel ?></a>
                <ul class="navbar-nav">
                    <li class="nav-item <?php echo ($current_page == "home" || $current_page == "") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>" class="nav-link"><?php echo trans("nav_home"); ?></a></li>
                    <li class="nav-item <?php echo ($current_page == "listings") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/listings" class="nav-link"><?php echo trans("nav_listings"); ?></a></li>
                    <li class="nav-item <?php echo ($current_page == "about") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/about" class="nav-link"><?php echo trans("nav_about"); ?></a></li>
                    <li class="nav-item <?php echo ($current_page == "services") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/services" class="nav-link"><?php echo trans("nav_services"); ?></a></li>
                    <li class="nav-item <?php echo ($current_page == "contact") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/contact" class="nav-link"><?php echo trans("nav_contact"); ?></a></li>
                    <?php if (Src\Auth\AuthController::isLoggedIn()): ?>
                        <li class="nav-item <?php echo ($current_page == "profile") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/profile" class="nav-link"><?php echo trans("nav_profile"); ?></a></li>
                        <?php if (Src\Auth\AuthController::getCurrentUserRole() === "admin"): ?>
                             <li class="nav-item <?php echo (strpos($current_page, "admin") === 0) ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/admin/dashboard" class="nav-link"><?php echo trans("nav_admin"); ?></a></li>
                        <?php endif; ?>
                        <li class="nav-item"><a href="<?php echo SITE_URL; ?>/logout" class="nav-link"><?php echo trans("nav_logout"); ?></a></li>
                    <?php else: ?>
                        <li class="nav-item <?php echo ($current_page == "login") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/login" class="nav-link"><?php echo trans("nav_login"); ?></a></li>
                        <li class="nav-item <?php echo ($current_page == "register") ? "active" : ""; ?>"><a href="<?php echo SITE_URL; ?>/register" class="nav-link"><?php echo trans("nav_register"); ?></a></li>
                    <?php endif; ?>
                </ul>
                <div class="language-switcher">
                    <?php
                    $query_params = $_GET;
                    $current_url_path = strtok($_SERVER["REQUEST_URI"], ".");
                    ?>
                    <?php if ($lang["current_lang"] == "en"): ?>
                        <?php $query_params["lang"] = "ar"; ?>
                        <a href="<?php echo $current_url_path . "?" . http_build_query($query_params); ?>" lang="ar" hreflang="ar">العربية</a>
                    <?php else: ?>
                        <?php $query_params["lang"] = "en"; ?>
                        <a href="<?php echo $current_url_path . "?" . http_build_query($query_params); ?>" lang="en" hreflang="en">English</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>
    <main>

