    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> <?php echo trans("site_title"); ?>. <?php echo trans("all_rights_reserved", [], "All rights reserved."); // Example with a default fallback if key not in lang file ?></p>
        <p>
            <a href="<?php echo SITE_URL; ?>/privacy-policy.php"><?php echo trans("privacy_policy", [], "Privacy Policy"); ?></a> |
            <a href="<?php echo SITE_URL; ?>/terms-of-service.php"><?php echo trans("terms_of_service", [], "Terms of Service"); ?></a>
        </p>
    </footer>
    <script src="<?php echo SITE_URL; ?>/assets/js/script.js"></script>
    <!-- Add any other JS files or CDN links here -->
</body>
</html>

